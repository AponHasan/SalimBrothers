<div class="row">
    <div class="col-sm-10">
        <p align="left" style=" font-size: 16px;margin-bottom: 0px;padding-bottom: 0px;"> <b>TOTAL ( UNITS) in word- SAY US$:</b> {{$invoice[0]->invoice_total_in_word}}.     </p>
    </div>

    <div class="col-sm-2">
        <p align="left" style="font-weight: bold; font-size: 16px; margin-bottom: 0px;padding-bottom: 0px;margin-left: 10px;">US$. {{$invoice[0]->invoice_total_value}}</p>
    </div>
</div>
<div class="hr" style="width: 100%;background-color: black;height: 3px;">
</div>
<div class="row">
    <div class="col-sm-6">

    </div>

</div>